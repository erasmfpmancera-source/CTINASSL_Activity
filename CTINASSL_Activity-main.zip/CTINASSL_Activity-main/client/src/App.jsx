import React from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import home from './components/pages/home';
import about from './components/pages/about';
import header from './components/navbar/header';
import footer from './components/navbar/footer';

function App() {
  return (
    <>
      <router>
        <header>
          <routes>
            <route path="/" element={<home />} />
            <route path="/about" element={<about />} />
          </routes>
          </header>
          </router>
          </>
  )
}

export default App