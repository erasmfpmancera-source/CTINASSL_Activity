import React from 'react'
import '../styles/footer.css'

function footer() {
  return (
    <>
<footer>
  <h2>Footer</h2>
</footer>
    </>
  )
}

export default footer