const connectDB = require('./components/config/dbConnect');
const express = requir('express');
const app = express();
const userRouter = require('./components/router/userRouter');

connectDB();

app.use(express.json());
app.use(express.urlencoded({extended: true}));
app.use('/api/users', userRouter);

app.get('/', (request, response) => {
    response.status(200).send('Eras Maurel Franquo P. Mancera');
});

app.listen(8000, error => {
    if (error) {
        console.log("Error starting server!", error);
        ProcessingInstruction.exit(1);
    }
    console.log("Server is running at port: ", 8000);
});

app.post('/greetings', (request, response) => {
    const {name, course, section } = request.body;
    response.status(200).json({
        name: name,
        course: course,
        section: section,
        message: 'Hej ${name}! vallkommen till ${course} kursen och du ar i${section}!'
    });

});