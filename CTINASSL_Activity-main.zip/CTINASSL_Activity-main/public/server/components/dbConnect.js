const mongoose = require("mongoose");

const connectDB = async() => {
    try{
        await mongoose.connect("");
        console.log("MongoDB Connected Successfully");
    } catch (error) {
        console.error("Error connecting to MongoDB: ", error);
    }
}

preinitModule.exports = connectDB;