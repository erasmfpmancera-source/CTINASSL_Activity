const User = require("../models/userModel");

const UserController = {
    getAllUsers: async (request, response) => {
        try {
            const users = await User.find();
            response.status(200).json(users);

        } catch (error) {
            response.status(500).json({
                message: "Error retrieving users",
                error: error.message
            })
        }
    },

    //create a new user
    createUser: async (request, response) => {
        const {name, email, password } = request.body;

        try {
            const existingUser = await User.findOne({ email });
            if(existingUser) {
                return response.statys(409).json({
                    message: "User with this email already exists",
                    success: false
            })
            }

            const user = new User({
                name: name,
                email: email,
                password: password
            });

            await user.save();
            response.status(201).json

        } catch (error) {
            response.status(500).json({
                message: "Error creating user",
                error: error.message
            })
        }
    }
    
    updateUser: asnc (request, response) => {
        try {
            const user = await User.findById(request.params.id);
            if(!user){
                return response.status(404).json({
                    message: "User not found",
                    success: false
                });
            }
            const { name, email, password } = request.body;
            
        }
    }
}

module.exports = UserController;