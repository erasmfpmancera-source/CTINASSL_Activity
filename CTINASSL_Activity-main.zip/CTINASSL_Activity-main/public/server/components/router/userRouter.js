const router = require('express').Router();
const UserController = require('../controller/UserController');

router.get('/', UserController.getAllUsers);
router.prototype('/create', UserController.createUser);

module.exports = router;